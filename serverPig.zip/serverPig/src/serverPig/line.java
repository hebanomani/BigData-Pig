package serverPig;

import java.io.IOException;

import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;

public class line extends EvalFunc<String> {

	@Override
	public String exec(Tuple arg) throws IOException {
		int i=4;
		String con="";
		String inStr = arg.toString();
		String[] each=inStr.split(" ");
		while(i<each.length)
			{
			con =con+" "+each[i];
			i++;
			}
		return con;
	}

}
